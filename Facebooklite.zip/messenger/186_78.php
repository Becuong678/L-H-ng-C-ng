<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/4124532.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=186" class="font-weight-bold text-dark">
<span style="font-size:16px">Jos Hoàng Tiên</span>
<small>06:21 03-12-2020</small>
<br><span class='mess-user-text'>test</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/c48dc0dd02322ab42eb8f903d3054c4c.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Cao Huy</span>
<small>07:02 03-12-2020</small>
<br><span class='mess-user-text'>test</span>

</a></div></div></div>
