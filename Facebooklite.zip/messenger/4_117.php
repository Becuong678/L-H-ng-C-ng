<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Kunloc Entertainment</span>
<small></small>
<small>01:37 05-12-2020</small>
<br><span class='mess-user-text'>#xoa</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=117" class="font-weight-bold text-dark">
<span style="font-size:16px">Kunloc Entertainment</span>
<small></small>
<small>01:37 05-12-2020</small>
<br><span class='mess-user-text'>whhshsjsjs</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=117" class="font-weight-bold text-dark">
<span style="font-size:16px">☆ K u n l o c</span>
<small>06:21 06-12-2020</small>
<br><span class='mess-user-text'>43543</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=117" class="font-weight-bold text-dark">
<span style="font-size:16px">☆ K u n l o c</span>
<small>06:22 06-12-2020</small>
<br><span class='mess-user-text'>5665</span>

</a></div></div></div>
