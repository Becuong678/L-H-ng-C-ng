<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=503" class="font-weight-bold text-dark">
<span style="font-size:16px">Ngô Duy Khánh Hưng</span>
<small>09:52 12-12-2020</small>
<br><span class='mess-user-text'>web load hơi chậm lộc oiwiiiiii ;-;</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=" class="font-weight-bold text-dark">
<span style="font-size:16px">Ngô Duy Khánh Hưng</span>
<small>09:52 12-12-2020</small>
<br><span class='mess-user-text'>web load hơi chậm lộc oiwiiiiii ;-;</span>

</a></div></div></div>
