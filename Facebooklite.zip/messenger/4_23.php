<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/7f947b8187f82ab9babdfdd679cc7d3b.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Kunloc Entertainment</span>
<small>09:36 02-12-2020</small>
<br><span class='mess-user-text'>#xoa</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/7f947b8187f82ab9babdfdd679cc7d3b.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=23" class="font-weight-bold text-dark">
<span style="font-size:16px">Kunloc Entertainment</span>
<small>09:36 02-12-2020</small>
<br><span class='mess-user-text'>Thử duyệt tôi nào</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/79515135_10111007623880301_5111576226921709568_o.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=23" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Đình Hưng</span>
<small></small>
<small>09:39 02-12-2020</small>
<br><span class='mess-user-text'>Chúng nó chane ip kiểu gì nhể :))</span>

</a></div></div></div>
