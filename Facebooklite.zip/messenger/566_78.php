<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=566" class="font-weight-bold text-dark">
<span style="font-size:16px">ミ★Çą๏ Văй ℌųу★彡</span>
<small>08:09 14-12-2020</small>
<br><span class='mess-user-text'>hello</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">ミ★Çą๏ Văй ℌųу★彡</span>
<small>08:09 14-12-2020</small>
<br><span class='mess-user-text'>Nhớ t k</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>11:35 15-12-2020</small>
<br><span class='mess-user-text'>Nhớ chứ mày :v</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">ミ★Çą๏ Văй ℌųу★彡</span>
<small>08:39 19-12-2020</small>
<br><span class='mess-user-text'>lô</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">ミ★Çą๏ Văй ℌųу★彡</span>
<small>08:39 19-12-2020</small>
<br><span class='mess-user-text'>lô</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>08:41 19-12-2020</small>
<br><span class='mess-user-text'>sao</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">ミ★Çą๏ Văй ℌųу★彡</span>
<small>08:41 19-12-2020</small>
<br><span class='mess-user-text'>Xin suport</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>08:44 19-12-2020</small>
<br><span class='mess-user-text'>xin lộc ớ</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>08:44 19-12-2020</small>
<br><span class='mess-user-text'>Mà khoảng 30k sud mới có support</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">ミ★Çą๏ Văй ℌųу★彡</span>
<small>08:47 19-12-2020</small>
<br><span class='mess-user-text'>10tr sub r</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>08:48 19-12-2020</small>
<br><span class='mess-user-text'>Mà sao bữa trước cho acc này vậy</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>08:48 19-12-2020</small>
<br><span class='mess-user-text'>Thi à</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">ミ★Çą๏ Văй ℌųу★彡</span>
<small>08:48 19-12-2020</small>
<br><span class='mess-user-text'>K</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">ミ★Çą๏ Văй ℌųу★彡</span>
<small>08:48 19-12-2020</small>
<br><span class='mess-user-text'>Chán</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>08:49 19-12-2020</small>
<br><span class='mess-user-text'>Support duyệt bậy là ban nha con</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">ミ★Çą๏ Văй ℌųу★彡</span>
<small>08:49 19-12-2020</small>
<br><span class='mess-user-text'>Ùm</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">ミ★Çą๏ Văй ℌųу★彡</span>
<small>08:49 19-12-2020</small>
<br><span class='mess-user-text'>Má ông sao xin đc admin vậy</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>08:52 19-12-2020</small>
<br><span class='mess-user-text'>Trùm web có khác chứ :v</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>08:54 19-12-2020</small>
<br><span class='mess-user-text'>Ném cái Zalo ib cho dễ</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">ミ★Çą๏ Văй ℌųу★彡</span>
<small>08:54 19-12-2020</small>
<br><span class='mess-user-text'>:v</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>08:55 19-12-2020</small>
<br><span class='mess-user-text'>Ném đi</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>06:15 20-12-2020</small>
<br><span class='mess-user-text'>Ném support cho mày rồi đó ku</span>

</a></div></div></div>
