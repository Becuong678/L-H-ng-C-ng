<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=178" class="font-weight-bold text-dark">
<span style="font-size:16px">Vo Viet Hung ✔( CEO )</span>
<small>08:14 11-12-2020</small>
<br><span class='mess-user-text'>Benbroken.CEO</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=176" class="font-weight-bold text-dark">
<span style="font-size:16px">Vo Viet Hung ✔( CEO )</span>
<small>08:14 11-12-2020</small>
<br><span class='mess-user-text'>kunlocs</span>

</a></div></div></div>
