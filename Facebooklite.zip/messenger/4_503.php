<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">NGUYỄN THÀNH LỘC</span>
<small>09:42 18-12-2020</small>
<br><span class='mess-user-text'>#xoa</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=503" class="font-weight-bold text-dark">
<span style="font-size:16px">NGUYỄN THÀNH LỘC</span>
<small>09:42 18-12-2020</small>
<br><span class='mess-user-text'>:v</span>

</a></div></div></div>
