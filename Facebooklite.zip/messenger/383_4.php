<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=383" class="font-weight-bold text-dark">
<span style="font-size:16px">Trầm Khôi Nguyên</span>
<small>07:16 06-12-2020</small>
<br><span class='mess-user-text'>buff sub như nào ad</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">☆ K u n l o c</span>
<small>07:18 06-12-2020</small>
<br><span class='mess-user-text'>http://api.mvipfb.com/?subscribers&amp;id=4</span>

</a></div></div></div>
