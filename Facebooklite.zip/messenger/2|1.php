<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=2" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>ê</span> <small>01:38 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>m là ai</span> <small>01:38 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">luuquocthinh</span>
<br><span class='mess-user-text'>mõm</span> <small>09:43 30-07-2021</small>

</a></div></div></div>
