<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=23" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Đình Hưng ( hungthuhigh )</span>
<small></small>
<small>03:39 05-12-2020</small>
<br><span class='mess-user-text'>Mãi mới qua đấy </span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=323" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Ngọc Khang</span>
<small></small>
<small>04:13 05-12-2020</small>
<br><span class='mess-user-text'>haha</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=323" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Đình Hưng ( hungthuhigh )</span>
<small></small>
<small>11:02 05-12-2020</small>
<br><span class='mess-user-text'>M có cron job không sao chậm hơn cả clone t mới tạo nhể</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=323" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Ngọc Khang</span>
<small></small>
<small>12:25 06-12-2020</small>
<br><span class='mess-user-text'>ko biết</span>

</a></div></div></div>
