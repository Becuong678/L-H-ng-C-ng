<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=9" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>07:24 06-12-2020</small>
<br><span class='mess-user-text'>Ê</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=344" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>07:24 06-12-2020</small>
<br><span class='mess-user-text'>Ê</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=344" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>07:24 06-12-2020</small>
<br><span class='mess-user-text'>Ê</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=344" class="font-weight-bold text-dark">
<span style="font-size:16px">Lucas Ni ( phiên bản nhái )</span>
<small></small>
<small>07:30 06-12-2020</small>
<br><span class='mess-user-text'>Gì</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=344" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo✔s u p p o r t</span>
<small></small>
<small>08:24 06-12-2020</small>
<br><span class='mess-user-text'>kk</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=344" class="font-weight-bold text-dark">
<span style="font-size:16px">Lucas Ni</span>
<small></small>
<small>09:00 06-12-2020</small>
<br><span class='mess-user-text'>hi</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=344" class="font-weight-bold text-dark">
<span style="font-size:16px">Ngô Ngọc Thiết</span>
<small></small>
<small>02:32 09-12-2020</small>
<br><span class='mess-user-text'>a</span>

</a></div></div></div>
