<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=364" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>08:02 07-12-2020</small>
<br><span class='mess-user-text'>Share acc đi</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>08:03 07-12-2020</small>
<br><span class='mess-user-text'>Cho tôi đi </span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Cao Văn Huy ✔</span>
<small></small>
<small>08:04 07-12-2020</small>
<br><span class='mess-user-text'>Hello</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Cao Văn Huy ✔</span>
<small></small>
<small>08:04 07-12-2020</small>
<br><span class='mess-user-text'>Rep -_-</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>08:05 07-12-2020</small>
<br><span class='mess-user-text'>Cho xin với</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>08:05 07-12-2020</small>
<br><span class='mess-user-text'>:v Cho xin acc đi</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>08:06 07-12-2020</small>
<br><span class='mess-user-text'>Rep :v</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Cao Văn Huy ✔</span>
<small></small>
<small>08:07 07-12-2020</small>
<br><span class='mess-user-text'>Tk: caovanhuy2k Mk : Caovanhuy2k</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Cao Văn Huy ✔</span>
<small></small>
<small>08:07 07-12-2020</small>
<br><span class='mess-user-text'>đó</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>01:22 09-12-2020</small>
<br><span class='mess-user-text'>Ê</span>

</a></div></div></div>
