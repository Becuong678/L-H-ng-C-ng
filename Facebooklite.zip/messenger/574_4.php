<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=574" class="font-weight-bold text-dark">
<span style="font-size:16px">lololol</span>
<small>10:42 16-12-2020</small>
<br><span class='mess-user-text'>ewrewr</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Page này nói Yêu Linh</span>
<small>11:07 16-12-2020</small>
<br><span class='mess-user-text'>456456</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Page này nói Yêu Linh</span>
<small>08:41 16-12-2020</small>
<br><span class='mess-user-text'>234334243</span>

</a></div></div></div>
