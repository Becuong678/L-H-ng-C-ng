<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/c5009b483c421ab6b1fabc80aba4b063.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Kunloc Entertainment</span>
<small></small>
<small>09:41 05-12-2020</small>
<br><span class='mess-user-text'>BOT: Xin chào, pr site giúp mình nhé ❤</span>

</a></div></div></div>
