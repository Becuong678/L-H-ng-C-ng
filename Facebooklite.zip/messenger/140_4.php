<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=140" class="font-weight-bold text-dark">
<span style="font-size:16px">hyouka </span>
<small></small>
<small>06:21 07-12-2020</small>
<br><span class='mess-user-text'>Yêu anh</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">K u n l o c</span>
<small>06:22 07-12-2020</small>
<br><span class='mess-user-text'>repp</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">hyouka </span>
<small></small>
<small>11:06 08-12-2020</small>
<br><span class='mess-user-text'>Xin support :))</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Thành Lộc</span>
<small>08:59 08-12-2020</small>
<br><span class='mess-user-text'>Đợi ổn định đã</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">hyouka </span>
<small></small>
<small>12:51 09-12-2020</small>
<br><span class='mess-user-text'>Dạ ok anh zai:3</span>

</a></div></div></div>
