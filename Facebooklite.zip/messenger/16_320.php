<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=16" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Hao Nguyen</span>
<small>08:41 10-12-2020</small>
<br><span class='mess-user-text'>cho xin link buff sub bạn ơi</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=320" class="font-weight-bold text-dark">
<span style="font-size:16px">Đặng Quang Khải✓ ۝</span>
<small>08:53 11-12-2020</small>
<br><span class='mess-user-text'>s bạn </span>

</a></div></div></div>
