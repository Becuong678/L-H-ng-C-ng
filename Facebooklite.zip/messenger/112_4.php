<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/khung long.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=112" class="font-weight-bold text-dark">
<span style="font-size:16px">Trung Hoang</span>
<small>12:16 03-12-2020</small>
<br><span class='mess-user-text'>Anh ơi </span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/7f947b8187f82ab9babdfdd679cc7d3b.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Kunloc Entertainment</span>
<small></small>
<small>08:14 03-12-2020</small>
<br><span class='mess-user-text'>oke</span>

</a></div></div></div>
