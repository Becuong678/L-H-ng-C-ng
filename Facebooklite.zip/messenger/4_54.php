<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Bạn Lộc Giấu Tên</span>
<small>10:08 10-12-2020</small>
<br><span class='mess-user-text'>#xoa</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=54" class="font-weight-bold text-dark">
<span style="font-size:16px">Bạn Lộc Giấu Tên</span>
<small>10:08 10-12-2020</small>
<br><span class='mess-user-text'>Vấn đề bị checkpoint là do lỗi code. Điều này đã được khắc phục</span>

</a></div></div></div>
