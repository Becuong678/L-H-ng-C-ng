<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Đào Xuân Đang</span>
<small></small>
<small>07:33 08-12-2020</small>
<br><span class='mess-user-text'>bác ơi e xin chân support</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Thành Lộc</span>
<small>08:00 08-12-2020</small>
<br><span class='mess-user-text'>Đợi ổn định đã</span>

</a></div></div></div>
