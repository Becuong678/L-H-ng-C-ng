<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=326" class="font-weight-bold text-dark">
<span style="font-size:16px">Đặng Cao Trí</span>
<small>03:07 05-12-2020</small>
<br><span class='mess-user-text'>alo</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=320" class="font-weight-bold text-dark">
<span style="font-size:16px">Đặng Quang Khải</span>
<small></small>
<small>03:21 05-12-2020</small>
<br><span class='mess-user-text'>lo cc</span>

</a></div></div></div>
