<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/72b0a0b2-9e40-4b70-8938-b4d29ac7fc14.jpeg"/>
<div class="mess-user-you">
<a href="profile.php?id=8" class="font-weight-bold text-dark">
<span style="font-size:16px">Vũ Hoàng Phát Tài</span>
<small></small>
<small>04:48 02-12-2020</small>
<br><span class='mess-user-text'>hú</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/234234.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Bạn Lộc Giấu Tên</span>
<small></small>
<small>05:14 02-12-2020</small>
<br><span class='mess-user-text'>❤</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/72b0a0b2-9e40-4b70-8938-b4d29ac7fc14.jpeg"/>
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Vũ Hoàng Phát Tài</span>
<small></small>
<small>08:45 02-12-2020</small>
<br><span class='mess-user-text'>adu vjp</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/7f947b8187f82ab9babdfdd679cc7d3b.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Kunloc Entertainment</span>
<small></small>
<small>09:04 02-12-2020</small>
<br><span class='mess-user-text'>:V</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/c5009b483c421ab6b1fabc80aba4b063.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Kunloc Entertainment</span>
<small></small>
<small>09:41 05-12-2020</small>
<br><span class='mess-user-text'>BOT: Xin chào, pr site giúp mình nhé ❤</span>

</a></div></div></div>
