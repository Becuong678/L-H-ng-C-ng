<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=587" class="font-weight-bold text-dark">
<span style="font-size:16px">Bùi Việt Hoàng ✓</span>
<small>02:06 19-12-2020</small>
<br><span class='mess-user-text'>Dmm</span>

</a></div></div></div>
