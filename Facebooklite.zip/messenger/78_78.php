<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Cao Văn Huy ✔</span>
<small></small>
<small>08:09 07-12-2020</small>
<br><span class='mess-user-text'>tk là : caovanhuy2k@gmail.com | Hả</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>03:02 09-12-2020</small>
<br><span class='mess-user-text'>lol má bảo bị tự kỉ hả ba</span>

</a></div></div></div>
