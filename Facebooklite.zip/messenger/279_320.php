<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=279" class="font-weight-bold text-dark">
<span style="font-size:16px">Long Phạm</span>
<small>03:09 05-12-2020</small>
<br><span class='mess-user-text'>vjp</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=320" class="font-weight-bold text-dark">
<span style="font-size:16px">Đặng Quang Khải</span>
<small></small>
<small>03:22 05-12-2020</small>
<br><span class='mess-user-text'>&gt;?</span>

</a></div></div></div>
