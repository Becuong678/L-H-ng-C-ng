<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>06:21 20-12-2020</small>
<br><span class='mess-user-text'>#xoa</span>

</a></div></div></div>
