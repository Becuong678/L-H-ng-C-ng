<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>06:58 15-12-2020</small>
<br><span class='mess-user-text'>Sao em</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=559" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Duy Hiển</span>
<small>09:23 15-12-2020</small>
<br><span class='mess-user-text'>kết bạn với em</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=559" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>06:09 16-12-2020</small>
<br><span class='mess-user-text'>Rồi nha</span>

</a></div></div></div>
