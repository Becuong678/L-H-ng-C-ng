<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=176" class="font-weight-bold text-dark">
<span style="font-size:16px">Viet Hung </span>
<small>03:39 11-12-2020</small>
<br><span class='mess-user-text'>acc em sao r anh trai</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Bạn Lộc Giấu Tên</span>
<small>06:10 11-12-2020</small>
<br><span class='mess-user-text'>login dc r ma</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Viet Hung </span>
<small>08:10 11-12-2020</small>
<br><span class='mess-user-text'>có vào đc đâu</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Viet Hung </span>
<small>08:11 11-12-2020</small>
<br><span class='mess-user-text'>check lai di la biet chu em vao khong duoc</span>

</a></div></div></div>
