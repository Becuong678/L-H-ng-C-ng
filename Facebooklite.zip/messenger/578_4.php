<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=578" class="font-weight-bold text-dark">
<span style="font-size:16px">NGUYỄN342342 THÀNH LỘC</span>
<small>09:05 16-12-2020</small>
<br><span class='mess-user-text'>234234</span>

</a></div></div></div>
