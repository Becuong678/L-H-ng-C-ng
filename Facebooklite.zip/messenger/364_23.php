<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=364" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>02:44 07-12-2020</small>
<br><span class='mess-user-text'>:v</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=23" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Đình Hưng (BT)</span>
<small>05:38 07-12-2020</small>
<br><span class='mess-user-text'>ccccc</span>

</a></div></div></div>
