<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/7f947b8187f82ab9babdfdd679cc7d3b.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Kunloc Entertainment</span>
<small></small>
<small>07:24 02-12-2020</small>
<br><span class='mess-user-text'>Xin chào, mình là Kunloc . giúp mình kéo member vào nhé ❤</span>

</a></div></div></div>
