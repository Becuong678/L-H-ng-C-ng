<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/ee58fcc0ff45002b8d416bd7685809ce_1487040461.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=178" class="font-weight-bold text-dark">
<span style="font-size:16px">Hùng Cute Phô Mai Que hehe</span>
<small></small>
<small>02:32 04-12-2020</small>
<br><span class='mess-user-text'>alo</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/[ Series ] [ MonstaX ] My Type.jpeg"/>
<div class="mess-user-you">
<a href="profile.php?id=23" class="font-weight-bold text-dark">
<span style="font-size:16px">Vo Viet Hung ✔( CEO )</span>
<small></small>
<small>11:20 04-12-2020</small>
<br><span class='mess-user-text'>My check my check</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/79515135_10111007623880301_5111576226921709568_o.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=23" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Đình Hưng ( hungthuhigh )</span>
<small></small>
<small>11:21 04-12-2020</small>
<br><span class='mess-user-text'>oke</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/[ Series ] [ MonstaX ] My Type.jpeg"/>
<div class="mess-user-you">
<a href="profile.php?id=23" class="font-weight-bold text-dark">
<span style="font-size:16px">Vo Viet Hung ✔( CEO )</span>
<small></small>
<small>11:21 04-12-2020</small>
<br><span class='mess-user-text'>Thấy ổn định chưa </span>

</a></div></div></div>
