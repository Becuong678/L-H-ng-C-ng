<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=358" class="font-weight-bold text-dark">
<span style="font-size:16px">Đỗ Quang Linh</span>
<small>10:19 06-12-2020</small>
<br><span class='mess-user-text'>alo bro</span>

</a></div></div></div>
