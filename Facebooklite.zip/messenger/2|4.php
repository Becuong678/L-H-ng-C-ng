<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=2" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>tick chú tuổi lồn :)))</span> <small>02:11 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>m ch đủ tuổi mà xin tick :)))</span> <small>02:11 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>tuổi :)))))</span> <small>02:11 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Ngô Minh Hiếu</span>
<br><span class='mess-user-text'>cho xin đi mà</span> <small>02:13 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Ngô Minh Hiếu</span>
<br><span class='mess-user-text'>up facebook cho bạn sợ</span> <small>02:14 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>hỏi ad đó :))))</span> <small>02:14 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>cho m r đấy</span> <small>02:22 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Ngô Minh Hiếu</span>
<br><span class='mess-user-text'>mơn anh</span> <small>02:26 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Ngô Minh Hiếu</span>
<br><span class='mess-user-text'>buff like sao a</span> <small>02:27 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>có api</span> <small>06:57 02-07-2021</small>

</a></div></div></div>
