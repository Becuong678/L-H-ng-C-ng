<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo₂₀₀₈(Gk)</span>
<small>12:14 08-12-2020</small>
<br><span class='mess-user-text'>Ông ơi</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=9" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo₂₀₀₈(Gk)</span>
<small>12:14 08-12-2020</small>
<br><span class='mess-user-text'>Cho tôi lên top 2 với</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=9" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>12:33 09-12-2020</small>
<br><span class='mess-user-text'>Cho xin cái acc này ( Nhường acc )</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=9" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>02:02 09-12-2020</small>
<br><span class='mess-user-text'>Kh rep phải kh</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=9" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>02:03 09-12-2020</small>
<br><span class='mess-user-text'>Die dáng chịu</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=9" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>04:44 09-12-2020</small>
<br><span class='mess-user-text'>lv</span>

</a></div></div></div>
