<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=22" class="font-weight-bold text-dark">
<span style="font-size:16px">۝Ma Văn Khánh ✓ ✿ ✪ </span>
<small></small>
<small>12:22 08-12-2020</small>
<br><span class='mess-user-text'>Chỉ tui mẹo buff sub vs</span>

</a></div></div></div>
