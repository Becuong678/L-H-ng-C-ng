<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>acc bị sao :)))))</span> <small>07:55 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh</span>
<br><span class='mess-user-text'>mất</span> <small>07:56 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh</span>
<br><span class='mess-user-text'>lấy lại dùm i</span> <small>07:56 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>lmj mà bị mất :))))</span> <small>07:59 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh</span>
<br><span class='mess-user-text'>gắn token bậy</span> <small>08:00 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>:)))</span> <small>08:01 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>tk mk coi nào</span> <small>08:01 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh</span>
<br><span class='mess-user-text'>tk dichvufbvn.net</span> <small>08:01 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh</span>
<br><span class='mess-user-text'>mk 0908863622thinhcute</span> <small>08:02 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh</span>
<br><span class='mess-user-text'>lấy dùm nhen</span> <small>08:02 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>mới coi đc cái tut hầu chiều :))</span> <small>08:03 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh</span>
<br><span class='mess-user-text'>ok lấy đi</span> <small>08:03 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>acc có gmailhay sđt k</span> <small>08:03 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>đcm rep lẹ</span> <small>08:04 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>t còn đi ngủ :)))))</span> <small>08:04 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh</span>
<br><span class='mess-user-text'>okok\\\\</span> <small>08:05 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh</span>
<br><span class='mess-user-text'>có gmail hà</span> <small>08:05 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh</span>
<br><span class='mess-user-text'>mà nó ko gửi qua mail</span> <small>08:05 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>acc m có gắn gmail k</span> <small>08:09 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>hay sđt</span> <small>08:09 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh</span>
<br><span class='mess-user-text'>có</span> <small>08:31 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh</span>
<br><span class='mess-user-text'>gắn mail</span> <small>08:31 04-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>đọc gmail </span> <small>07:16 05-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh</span>
<br><span class='mess-user-text'>thinhthichpha@gmail.com</span> <small>10:18 05-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>vãi </span> <small>11:13 05-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>acc m đâu có gmail này</span> <small>11:13 05-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>có fb lại ch :)))))</span> <small>07:24 05-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Quốc Thịnh</span>
<br><span class='mess-user-text'>chx</span> <small>08:09 05-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>ai biều m khóa fb t :))))</span> <small>08:52 05-07-2021</small>

</a></div></div></div>
