<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=9" class="font-weight-bold text-dark">
<span style="font-size:16px">Lucas Ni ( phiên bản nhái )</span>
<small></small>
<small>07:40 06-12-2020</small>
<br><span class='mess-user-text'>Anh ơi</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=23" class="font-weight-bold text-dark">
<span style="font-size:16px">Lucas Ni ( phiên bản nhái )</span>
<small></small>
<small>07:40 06-12-2020</small>
<br><span class='mess-user-text'>Em xin cái acc với ( Gia Bảo đây )</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=23" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Đình Hưng (BT)</span>
<small>07:41 06-12-2020</small>
<br><span class='mess-user-text'>:v chịu ấy</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=23" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>07:50 06-12-2020</small>
<br><span class='mess-user-text'>Anh còn acc nào không ạ :v Chứ em mới vô wed nên đâu biết acc nhiều :v</span>

</a></div></div></div>
