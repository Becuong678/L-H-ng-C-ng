<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=571" class="font-weight-bold text-dark">
<span style="font-size:16px">Đào Ngọc Tiên</span>
<small>12:45 16-12-2020</small>
<br><span class='mess-user-text'>alo</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=568" class="font-weight-bold text-dark">
<span style="font-size:16px">Đào Ngọc Tiên</span>
<small>12:45 16-12-2020</small>
<br><span class='mess-user-text'>thông điên </span>

</a></div></div></div>
