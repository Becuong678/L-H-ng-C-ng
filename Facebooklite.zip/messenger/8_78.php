<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=8" class="font-weight-bold text-dark">
<span style="font-size:16px">Vũ Hoàng Phát Tài</span>
<small></small>
<small>10:52 08-12-2020</small>
<br><span class='mess-user-text'>hi</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo₂₀₀₈(Gk)</span>
<small>11:44 08-12-2020</small>
<br><span class='mess-user-text'>Hả</span>

</a></div></div></div>
