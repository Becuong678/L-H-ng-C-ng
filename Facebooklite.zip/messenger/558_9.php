<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=558" class="font-weight-bold text-dark">
<span style="font-size:16px">Lucas N</span>
<small>06:02 13-12-2020</small>
<br><span class='mess-user-text'>https://drive.google.com/drive/folders/1-OPBVmDI-YzeD5dXHHyzcGJ0dvnghs7s</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=9" class="font-weight-bold text-dark">
<span style="font-size:16px">Lucas N</span>
<small>06:11 13-12-2020</small>
<br><span class='mess-user-text'>https://www.crackingpro.com/index.php?/forum/23-combos/page/2/</span>

</a></div></div></div>
