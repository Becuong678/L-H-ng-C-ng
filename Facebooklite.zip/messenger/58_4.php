<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=58" class="font-weight-bold text-dark">
<span style="font-size:16px">Phạm Đức Thanh</span>
<small>09:36 08-12-2020</small>
<br><span class='mess-user-text'>hi</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Phạm Đức Thanh</span>
<small>09:38 08-12-2020</small>
<br><span class='mess-user-text'>rep coi nộc</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Thành Lộc</span>
<small>09:56 08-12-2020</small>
<br><span class='mess-user-text'>alo</span>

</a></div></div></div>
