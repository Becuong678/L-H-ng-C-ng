<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=2" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>sao m nói k bufff fl lên đc à</span> <small>02:27 03-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=12" class="font-weight-bold text-dark">
<span style="font-size:16px">Letrong</span>
<br><span class='mess-user-text'>Đc</span> <small>02:28 03-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=12" class="font-weight-bold text-dark">
<span style="font-size:16px">Letrong</span>
<br><span class='mess-user-text'>Nhầm th r</span> <small>02:28 03-07-2021</small>

</a></div></div></div>
