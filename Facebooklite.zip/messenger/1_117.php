<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lê Phương Anh</span>
<small></small>
<small>02:44 07-12-2020</small>
<br><span class='mess-user-text'>12312323</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=117" class="font-weight-bold text-dark">
<span style="font-size:16px">Võ Hoài Link</span>
<small>02:45 07-12-2020</small>
<br><span class='mess-user-text'>1231232</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=117" class="font-weight-bold text-dark">
<span style="font-size:16px">Võ Hoài Link</span>
<small>02:45 07-12-2020</small>
<br><span class='mess-user-text'>sssssssssss</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=117" class="font-weight-bold text-dark">
<span style="font-size:16px">Võ Hoài Link</span>
<small>02:45 07-12-2020</small>
<br><span class='mess-user-text'>cc</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=117" class="font-weight-bold text-dark">
<span style="font-size:16px">Lê Phương Anh</span>
<small></small>
<small>02:45 07-12-2020</small>
<br><span class='mess-user-text'>ssd</span>

</a></div></div></div>
