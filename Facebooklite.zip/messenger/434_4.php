<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=434" class="font-weight-bold text-dark">
<span style="font-size:16px">Dương Minh Thông</span>
<small>01:40 09-12-2020</small>
<br><span class='mess-user-text'>Xin cái support đi pro</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Dương Minh Thông</span>
<small></small>
<small>10:49 10-12-2020</small>
<br><span class='mess-user-text'>Xin cái support nào</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Dương Minh Thông</span>
<small>08:07 12-12-2020</small>
<br><span class='mess-user-text'>Ủa admin</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Dương Minh Thông</span>
<small>08:07 12-12-2020</small>
<br><span class='mess-user-text'>Tích support của em đâu ạ</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Bạn Lộc Giấu Tên</span>
<small>08:11 12-12-2020</small>
<br><span class='mess-user-text'>reset tick . gui lai contact</span>

</a></div></div></div>
