<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=364" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>11:39 07-12-2020</small>
<br><span class='mess-user-text'>Cho tao xin nick kia đi mày } Tao xin luôn ớ :((</span>

</a></div></div></div>
