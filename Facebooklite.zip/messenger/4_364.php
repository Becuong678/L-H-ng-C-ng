<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">K u n l o c</span>
<small>07:05 07-12-2020</small>
<br><span class='mess-user-text'>#xoa</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=364" class="font-weight-bold text-dark">
<span style="font-size:16px">K u n l o c</span>
<small>07:05 07-12-2020</small>
<br><span class='mess-user-text'>truy cập: https://api.mvipfb.com</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=364" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>07:14 07-12-2020</small>
<br><span class='mess-user-text'>Truy cập vô thì sao nữa ạ</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=364" class="font-weight-bold text-dark">
<span style="font-size:16px">K u n l o c</span>
<small>07:16 07-12-2020</small>
<br><span class='mess-user-text'>vc</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=364" class="font-weight-bold text-dark">
<span style="font-size:16px">K u n l o c</span>
<small>07:16 07-12-2020</small>
<br><span class='mess-user-text'>https://api.mvipfb.com?subscribers&amp;id=UID</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=364" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>07:55 07-12-2020</small>
<br><span class='mess-user-text'>Mở link sud đi anh</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=364" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>12:47 08-12-2020</small>
<br><span class='mess-user-text'>Em xin cho acc này support được kh ạ</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=364" class="font-weight-bold text-dark">
<span style="font-size:16px">Bạn Lộc Giấu Tên</span>
<small>01:08 09-12-2020</small>
<br><span class='mess-user-text'>2 acc à</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=364" class="font-weight-bold text-dark">
<span style="font-size:16px">Bạn Lộc Giấu Tên</span>
<small>01:08 09-12-2020</small>
<br><span class='mess-user-text'>1 cái thôi </span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=364" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo</span>
<small></small>
<small>01:10 09-12-2020</small>
<br><span class='mess-user-text'>Lỡ bị pay acc kia còn lấy acc này duyệt chứ ad</span>

</a></div></div></div>
