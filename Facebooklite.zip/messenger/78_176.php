<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>12:55 10-12-2020</small>
<br><span class='mess-user-text'>Có chuyện gì vậy</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=176" class="font-weight-bold text-dark">
<span style="font-size:16px">Viet Hung </span>
<small>01:51 10-12-2020</small>
<br><span class='mess-user-text'>acc 9 t sao kh vào đc</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=176" class="font-weight-bold text-dark">
<span style="font-size:16px">Viet Hung </span>
<small>01:51 10-12-2020</small>
<br><span class='mess-user-text'>rõ ràng login đúng user mà</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=176" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>05:40 10-12-2020</small>
<br><span class='mess-user-text'>9 ?</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=176" class="font-weight-bold text-dark">
<span style="font-size:16px">Viet Hung </span>
<small>07:25 10-12-2020</small>
<br><span class='mess-user-text'>Xin lại link box zalo</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=176" class="font-weight-bold text-dark">
<span style="font-size:16px">Viet Hung </span>
<small>07:25 10-12-2020</small>
<br><span class='mess-user-text'>Fb-vn.com/178 acc chính của tao giờ vào kh đc nữa</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=176" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>07:29 10-12-2020</small>
<br><span class='mess-user-text'>0392817407</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=176" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>07:29 10-12-2020</small>
<br><span class='mess-user-text'>Số zalo đó</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=176" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>07:29 10-12-2020</small>
<br><span class='mess-user-text'>ib đi</span>

</a></div></div></div>
