<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Kunloc Entertainment</span>
<small></small>
<small>01:38 05-12-2020</small>
<br><span class='mess-user-text'>#xoa</span>

</a></div></div></div>
