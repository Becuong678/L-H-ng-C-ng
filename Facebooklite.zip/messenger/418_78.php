<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=418" class="font-weight-bold text-dark">
<span style="font-size:16px">Dương Gia Anh</span>
<small></small>
<small>04:46 09-12-2020</small>
<br><span class='mess-user-text'>da</span>

</a></div></div></div>
