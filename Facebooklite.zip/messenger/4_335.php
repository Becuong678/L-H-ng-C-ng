<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">☆ K u n l o c</span>
<small>06:32 06-12-2020</small>
<br><span class='mess-user-text'>#xoa</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=335" class="font-weight-bold text-dark">
<span style="font-size:16px">☆ K u n l o c</span>
<small>06:34 06-12-2020</small>
<br><span class='mess-user-text'>.</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=335" class="font-weight-bold text-dark">
<span style="font-size:16px">K u n l o c</span>
<small>06:18 07-12-2020</small>
<br><span class='mess-user-text'>test innbox</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=335" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Văn Dũng</span>
<small></small>
<small>09:25 07-12-2020</small>
<br><span class='mess-user-text'>xin 20k</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=335" class="font-weight-bold text-dark">
<span style="font-size:16px">K u n l o c</span>
<small>09:59 07-12-2020</small>
<br><span class='mess-user-text'>gắt</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=335" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Văn Dũng</span>
<small></small>
<small>09:41 08-12-2020</small>
<br><span class='mess-user-text'>nó không cho gửi nữa anh ạ</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=335" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Thành Lộc</span>
<small>09:56 08-12-2020</small>
<br><span class='mess-user-text'>ko cho gửi gì v</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=335" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Văn Dũng</span>
<small>09:20 11-12-2020</small>
<br><span class='mess-user-text'>3	Duyệt Từ chối (xóa)  Nguyễn Văn Dũng	8,942,175	Nhét em lên tick support cái :v	Đã xác minh</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=335" class="font-weight-bold text-dark">
<span style="font-size:16px">Bạn Lộc Giấu Tên</span>
<small>10:43 12-12-2020</small>
<br><span class='mess-user-text'>=))</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=335" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Văn Dũng</span>
<small>05:56 12-12-2020</small>
<br><span class='mess-user-text'>lấy token sao anh</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=335" class="font-weight-bold text-dark">
<span style="font-size:16px">Bạn Lộc Giấu Tên</span>
<small>08:11 12-12-2020</small>
<br><span class='mess-user-text'>ko can token</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=335" class="font-weight-bold text-dark">
<span style="font-size:16px">Nguyễn Văn Dũng</span>
<small>10:34 13-12-2020</small>
<br><span class='mess-user-text'>add lai em may cai tick voi </span>

</a></div></div></div>
