<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/72b0a0b2-9e40-4b70-8938-b4d29ac7fc14.jpeg"/>
<div class="mess-user-you">
<a href="profile.php?id=8" class="font-weight-bold text-dark">
<span style="font-size:16px">Vũ Hoàng Phát Tài</span>
<small></small>
<small>04:48 02-12-2020</small>
<br><span class='mess-user-text'>alo</span>

</a></div></div></div>
