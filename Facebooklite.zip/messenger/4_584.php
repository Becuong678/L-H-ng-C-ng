<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Page này nói Yêu Linh ❤</span>
<small>09:12 19-12-2020</small>
<br><span class='mess-user-text'>345345</span>

</a></div></div></div>
