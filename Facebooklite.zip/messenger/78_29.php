<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=78" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>07:44 08-12-2020</small>
<br><span class='mess-user-text'>Anh</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Đào Xuân Đang</span>
<small></small>
<small>07:45 08-12-2020</small>
<br><span class='mess-user-text'>sao nào</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>07:46 08-12-2020</small>
<br><span class='mess-user-text'>Lên tích support kh</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Đào Xuân Đang</span>
<small></small>
<small>07:50 08-12-2020</small>
<br><span class='mess-user-text'>như nào ?</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>07:51 08-12-2020</small>
<br><span class='mess-user-text'>Ném cái acc anh cho em</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>07:51 08-12-2020</small>
<br><span class='mess-user-text'>Xin cho</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>07:51 08-12-2020</small>
<br><span class='mess-user-text'>Em ib cho Ông Lộc</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Đào Xuân Đang</span>
<small></small>
<small>07:51 08-12-2020</small>
<br><span class='mess-user-text'>xuandang</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>07:51 08-12-2020</small>
<br><span class='mess-user-text'>Hôm qua em chả xin Lộc } Lộc cho luôn</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Đào Xuân Đang</span>
<small></small>
<small>07:51 08-12-2020</small>
<br><span class='mess-user-text'>dangpbtn</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>07:53 08-12-2020</small>
<br><span class='mess-user-text'>Tk mk</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>07:54 08-12-2020</small>
<br><span class='mess-user-text'>Kh vô được</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>07:54 08-12-2020</small>
<br><span class='mess-user-text'>Sai mk hay tk à</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Đào Xuân Đang</span>
<small></small>
<small>07:58 08-12-2020</small>
<br><span class='mess-user-text'>thôi bỏ đi</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=29" class="font-weight-bold text-dark">
<span style="font-size:16px">Gia Bảo¹(Gk)</span>
<small>08:00 08-12-2020</small>
<br><span class='mess-user-text'>:v</span>

</a></div></div></div>
