<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">K u n l o c</span>
<small>07:21 07-12-2020</small>
<br><span class='mess-user-text'>#xoa</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">K u n l o c</span>
<small>07:21 07-12-2020</small>
<br><span class='mess-user-text'>#xoaa</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">K u n l o c</span>
<small>07:22 07-12-2020</small>
<br><span class='mess-user-text'>456456</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lê Phương Anh</span>
<small></small>
<small>07:23 07-12-2020</small>
<br><span class='mess-user-text'>44554543</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lê Phương Anh</span>
<small></small>
<small>07:25 07-12-2020</small>
<br><span class='mess-user-text'>456546564</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">K u n l o c</span>
<small>07:28 07-12-2020</small>
<br><span class='mess-user-text'>123132</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Lê Phương Anh</span>
<small></small>
<small>07:28 07-12-2020</small>
<br><span class='mess-user-text'>12312123</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=1" class="font-weight-bold text-dark">
<span style="font-size:16px">Bạn Lộc Giấu Tên</span>
<small>04:04 09-12-2020</small>
<br><span class='mess-user-text'>555</span>

</a></div></div></div>
