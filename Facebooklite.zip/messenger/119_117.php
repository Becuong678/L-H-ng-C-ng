<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/Ảđd.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=119" class="font-weight-bold text-dark">
<span style="font-size:16px">le hung</span>
<small>10:38 02-12-2020</small>
<br><span class='mess-user-text'>hii</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/Hoai-Linh-thong-bao-thoi-diem-den-mien-Trung-117595025_2726886704078220_-1604890449-230-width660height660.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=117" class="font-weight-bold text-dark">
<span style="font-size:16px">Võ Hoài Link</span>
<small>08:15 03-12-2020</small>
<br><span class='mess-user-text'>:((</span>

</a></div></div></div>
