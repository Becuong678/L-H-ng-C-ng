<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=2" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>m k có cách thay đỏi số lượt like à</span> <small>01:39 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>lúc f5 thì tăng bn like ấy</span> <small>01:39 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh (15T)</span>
<br><span class='mess-user-text'>có tao đổi like trên php my admin</span> <small>01:40 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh (15T)</span>
<br><span class='mess-user-text'>tao bik lâu ròi</span> <small>01:40 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh (15T)</span>
<br><span class='mess-user-text'>tao gắn api ko tăng ms lạ</span> <small>01:40 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>í là m gắn api tăng like 1 lần f5 cớ 100 like v</span> <small>02:00 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>nhiều nhiều lên chớ 1 lần có 3,4 đưa j à</span> <small>02:00 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>reppppp </span> <small>07:16 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh (15T)</span>
<br><span class='mess-user-text'>thì phải tạo nick clone duma</span> <small>08:17 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>lồn m rep trên fb ấy thk ngu này</span> <small>08:55 02-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Lưu Quốc Thịnh (15T)</span>
<br><span class='mess-user-text'>rep gì</span> <small>10:45 03-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>trên fb :)))</span> <small>11:26 03-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Thịnh Entertaiment</span>
<br><span class='mess-user-text'>rep ở đây</span> <small>11:45 03-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>thế có code scam m ghi chưa cho t coi với</span> <small>02:19 03-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>ê</span> <small>02:29 03-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>code m có bị lỗi k v</span> <small>02:29 03-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Thịnh Entertaiment</span>
<br><span class='mess-user-text'>ko</span> <small>02:29 03-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>để t ra mắt api like cho</span> <small>02:31 03-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Thịnh Entertaiment</span>
<br><span class='mess-user-text'>ukm</span> <small>02:31 03-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>sao đăng link lên nó bị đen v m</span> <small>02:33 03-07-2021</small>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=3" class="font-weight-bold text-dark">
<span style="font-size:16px">Cúc Trịnh</span>
<br><span class='mess-user-text'>ê sao cho mấy kia lên ban điều hành v</span> <small>07:33 04-07-2021</small>

</a></div></div></div>
