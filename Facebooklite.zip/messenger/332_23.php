<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=332" class="font-weight-bold text-dark">
<span style="font-size:16px">Mark Đình Hưng ( hungthubar )</span>
<small></small>
<small>05:49 09-12-2020</small>
<br><span class='mess-user-text'>.</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=23" class="font-weight-bold text-dark">
<span style="font-size:16px">Mark Đình Hưng ( hungthubar )</span>
<small></small>
<small>05:49 09-12-2020</small>
<br><span class='mess-user-text'>das</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=23" class="font-weight-bold text-dark">
<span style="font-size:16px">Mark Đình Hưng ( hungthubar )</span>
<small></small>
<small>05:49 09-12-2020</small>
<br><span class='mess-user-text'>das</span>

</a></div></div></div>
