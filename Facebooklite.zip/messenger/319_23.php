<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<img class="card-img-64 d-flex mess-user-none mb-0" src="data/8ecc4fbea94cc0e54d092fb07e62a910.jpg"/>
<div class="mess-user-you">
<a href="profile.php?id=319" class="font-weight-bold text-dark">
<span style="font-size:16px">Trần Văn Long</span>
<small>01:00 05-12-2020</small>
<br><span class='mess-user-text'>ccc</span>

</a></div></div></div>
