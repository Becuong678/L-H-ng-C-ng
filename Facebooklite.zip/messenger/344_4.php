<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=344" class="font-weight-bold text-dark">
<span style="font-size:16px">Lucas Ni</span>
<small></small>
<small>06:13 06-12-2020</small>
<br><span class='mess-user-text'>hi bede</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Lucas Ni</span>
<small></small>
<small>06:15 06-12-2020</small>
<br><span class='mess-user-text'>Kun :))</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">K u n l o c</span>
<small>06:17 07-12-2020</small>
<br><span class='mess-user-text'>uh</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div  class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">K u n l o c</span>
<small>06:18 07-12-2020</small>
<br><span class='mess-user-text'>uh</span>

</a></div></div></div>
<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=4" class="font-weight-bold text-dark">
<span style="font-size:16px">Lucas Ni</span>
<small></small>
<small>12:03 09-12-2020</small>
<br><span class='mess-user-text'>cho tui làm chức vụ gì với</span>

</a></div></div></div>
