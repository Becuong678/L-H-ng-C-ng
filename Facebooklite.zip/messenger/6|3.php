<div class="media d-block d-md-flex mt-3">
<div class="tinnhan">
<div class="mess-user-you">
<a href="profile.php?id=6" class="font-weight-bold text-dark">
<span style="font-size:16px">Phạm Ngọc Trúc Linh (Bé ty)</span>
<br><span class='mess-user-text'>#xoa</span> <small>09:52 07-05-2021</small>

</a></div></div></div>
