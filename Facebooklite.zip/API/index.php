<?php
ob_start();
include("../config.php");
header("Location: $domain_url");
?>